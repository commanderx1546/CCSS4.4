# artifact32
THIS REPO IS PART OF WHAT ORCA TOLD ME TO UPLOAD

# Generate x86 arch undetactable executables directly from cobalt strike .

# USAGE :
- compile using visual studio 
- add the binaries to a directory (next to [artifact.cna](https://github.com/ORCA666/artifact32/blob/main/artifact.cna))
- load  [artifact.cna](https://github.com/ORCA666/artifact32/blob/main/artifact.cna) to cobalt strike 
- generate ur x64 binaries as usual 
